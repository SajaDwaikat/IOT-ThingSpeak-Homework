
//Channel ID : 3549989

// API key : HDZ9MPW9N7XPPTV7

#include <WiFi.h>
#include <ThingSpeak.h>
#include <DHT.h>

// WiFi Settings
const char* WIFI_Name = "Wokwi-GUEST";
const char* WIFI_Pass = "";

// ThingSpeak Settings
const unsigned long channelNumber = 3549989

;
const char* apiKey = "HDZ9MPW9N7XPPTV7";

// Student Information
const char* universityID = "12325663";

// DHT22 Sensor Settings
#define DHTPIN 15
#define DHTTYPE DHT22

DHT dht(DHTPIN, DHTTYPE);
WiFiClient clientObject;

void setup() {
  Serial.begin(115200);
  delay(1000);

  Serial.println("Starting ESP32...");

  dht.begin();

  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_Name, WIFI_Pass);

  while (WiFi.status() != WL_CONNECTED) {
    Serial.println("Status: Not Connected");
    delay(1000);
  }

  Serial.println("Status: Connected");

  ThingSpeak.begin(clientObject);
}

void loop() {
  float temperature = dht.readTemperature();
  float humidity = dht.readHumidity();

  if (isnan(temperature) || isnan(humidity)) {
    Serial.println("Failed to read from DHT22!");
    delay(2000);
    return;
  }

  Serial.print("University ID: ");
  Serial.println(universityID);

  Serial.print("Temperature: ");
  Serial.print(temperature);
  Serial.println(" C");

  Serial.print("Humidity: ");
  Serial.print(humidity);
  Serial.println(" %");

  ThingSpeak.setField(1, temperature);
  ThingSpeak.setField(2, humidity);

  int stat = ThingSpeak.writeFields(channelNumber, apiKey);

  if (stat == 200) {
    Serial.println("Data Sent to ThingSpeak!");
  } else {
    Serial.print("ThingSpeak Error: ");
    Serial.println(stat);
  }

  Serial.println(" DHT22 ");

  delay(20000);
}
